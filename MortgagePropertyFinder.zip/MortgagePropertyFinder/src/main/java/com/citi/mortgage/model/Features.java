package com.citi.mortgage.model;

public class Features {
private int numberofrooms;
private String description;
public int getNumberofrooms() {
	return numberofrooms;
}
public void setNumberofrooms(int numberofrooms) {
	this.numberofrooms = numberofrooms;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
	
}
